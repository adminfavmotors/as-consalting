import { company, services, clients, career } from './content.mjs';

export const escape = (value = '') => String(value).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const arrow = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
const diagonal = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M6 18 18 6M6 6h12v12"/></svg>';
const iconPaths = {
  scan: '<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5M7 9h10M7 13h10M7 17h5"/>',
  compass: '<circle cx="12" cy="12" r="9"/><path d="m16 8-2.5 5.5L8 16l2.5-5.5L16 8Z"/>',
  growth: '<path d="M4 20h16M6 16v-4m6 4V8m6 8V4M4 8l5-5 4 2 6-3"/>',
  people: '<circle cx="9" cy="8" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M16 5a3 3 0 0 1 0 6m2 3a5 5 0 0 1 3 4v3"/>',
  phone: '<path d="m8 3 3 5-3 3a18 18 0 0 0 5 5l3-3 5 3-1 4c-.2.8-1 1-2 1C10 20 4 14 3 6c0-1 .2-1.8 1-2l4-1Z"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="1"/><path d="m3 6 9 7 9-7"/>',
};
export function icon(name) { return `<svg viewBox="0 0 24 24" fill="none" aria-hidden="true">${iconPaths[name] || iconPaths.compass}</svg>`; }
const base = (route) => route ? '../'.repeat(route.split('/').length) : './';
export const link = (route, target = '') => `${base(route)}${target ? `${target}/` : ''}index.html`;
const asset = (route, name) => `${base(route)}assets/${name}`;
function button(route, target, label, secondary = false, extra = '') {
  return `<a class="button${secondary ? ' button-secondary' : ''}" href="${link(route, target)}${extra}">${label}${arrow}</a>`;
}
function topicButton(route, topic, label = 'Porozmawiajmy o współpracy') {
  return button(route, 'kontakt', label, false, `?temat=${encodeURIComponent(topic)}`);
}
function tag(text, light = false) { return `<p class="eyebrow${light ? ' eyebrow-light' : ''}"><span aria-hidden="true"></span>${text}</p>`; }
function sectionLabel(number, text) { return `<p class="section-label"><span>${number}</span>${text}</p>`; }
function breadcrumbs(route, title, service = false) {
  return `<nav class="breadcrumbs wrap" aria-label="Ścieżka nawigacji"><ol><li><a href="${link(route)}">Strona główna</a></li>${service ? `<li><a href="${link(route, 'oferta')}">Oferta</a></li>` : ''}<li aria-current="page">${escape(title)}</li></ol></nav>`;
}
function pageIntro(route, { eyebrow, heading, emphasis, intro, title }, service = false) {
  return `${breadcrumbs(route, title, service)}<section class="page-intro wrap">${tag(eyebrow)}<h1>${heading}<br><em>${emphasis}</em></h1><p class="lead">${intro}</p></section>`;
}
function serviceRows(route, compact = false) {
  return `<div class="service-list${compact ? ' service-list-compact' : ''}">${services.map((s) => `<a class="service-row" href="${link(route, s.path)}"><span class="service-number">${s.number}</span><div class="service-row-title"><span class="service-icon">${icon(s.icon)}</span><h3>${s.title}</h3></div><p>${s.description}</p><span class="round-arrow">${diagonal}</span></a>`).join('')}</div>`;
}
function faq(items) {
  return `<div class="faq-list">${items.map(([q, a]) => `<details><summary>${q}<span class="faq-plus" aria-hidden="true"></span></summary><div class="faq-answer"><p>${a}</p></div></details>`).join('')}</div>`;
}
function cta(route, options = {}) {
  return `<section class="contact-band"><div class="wrap contact-band-inner"><div>${tag('Kolejny krok', true)}<h2>${options.title || 'Zacznijmy od'}<br><em>${options.emphasis || 'dobrej rozmowy.'}</em></h2></div><div><p>${options.text || 'Opowiedz mi o swoim dealerstwie i wyzwaniach. Wspólnie określimy, gdzie warto zacząć.'}</p>${topicButton(route, options.topic || '', 'Porozmawiajmy') }<a class="contact-band-phone" href="tel:${company.phoneHref}">${company.phone}</a></div></div><span class="band-watermark" aria-hidden="true">A.S.</span></section>`;
}

function header(route) {
  const navItems = [['o-firmie', 'O mnie'], ['oferta', 'Oferta'], ['oferta/program-rozwoju-dealera', 'Program rozwoju'], ['klienci', 'Klienci']];
  return `<a class="skip-link" href="#main">Przejdź do treści</a><header class="site-header"><div class="wrap header-inner"><a href="${link(route)}" class="brand" aria-label="A.S. Consulting — strona główna"><span class="brand-mark">A.S<span>.</span></span><span class="brand-type">CONSULTING<span>ANDRZEJ SADOWSKI</span></span></a><button class="menu-toggle" type="button" aria-expanded="false" aria-controls="site-nav"><span class="menu-label">Menu</span><span class="menu-lines" aria-hidden="true"></span></button><nav id="site-nav" class="site-nav" aria-label="Nawigacja główna">${navItems.map(([target, label]) => `<a href="${link(route, target)}"${route === target ? ' aria-current="page"' : ''}>${label}</a>`).join('')}<a class="nav-cta" href="${link(route, 'kontakt')}"${route === 'kontakt' ? ' aria-current="page"' : ''}>Porozmawiajmy ${diagonal}</a></nav></div></header>`;
}
function footer(route) {
  return `<footer class="site-footer"><div class="wrap footer-top"><div class="footer-brand"><a href="${link(route)}" class="brand" aria-label="A.S. Consulting — strona główna"><span class="brand-mark">A.S<span>.</span></span><span class="brand-type">CONSULTING<span>ANDRZEJ SADOWSKI</span></span></a><p>Praktyka, która rozumie dealerstwo.<br>Doradztwo. Rozwój. Efektywność.</p></div><nav aria-label="Strony w stopce"><h2>Poznajmy się</h2><a href="${link(route, 'o-firmie')}">O mnie</a><a href="${link(route, 'klienci')}">Doświadczenie z klientami</a><a href="${link(route, 'kontakt')}">Kontakt</a></nav><nav aria-label="Usługi w stopce"><h2>Jak mogę pomóc</h2>${services.map((s) => `<a href="${link(route, s.path)}">${s.title}</a>`).join('')}</nav><div class="footer-contact"><h2>Bezpośredni kontakt</h2><a href="tel:${company.phoneHref}">${company.phone}</a><a href="mailto:${company.email}">${company.email}</a><p>Branża motoryzacyjna · Polska</p></div></div><div class="wrap footer-bottom"><span>A.S. Consulting · Andrzej Sadowski</span><a href="#top">Wróć na górę <span aria-hidden="true">↑</span></a></div></footer>`;
}

export function layout(page) {
  const { route = '', title, description, body } = page;
  return `<!doctype html>
<html lang="pl" id="top">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#193c36">
  <title>${escape(title)} | A.S. Consulting</title>
  <meta name="description" content="${escape(description)}">
  <meta property="og:type" content="website">
  <meta property="og:locale" content="pl_PL">
  <meta property="og:site_name" content="A.S. Consulting — Andrzej Sadowski">
  <meta property="og:title" content="${escape(title)}">
  <meta property="og:description" content="${escape(description)}">
  <link rel="icon" href="${asset(route, 'favicon.svg')}" type="image/svg+xml">
  <link rel="preload" href="${asset(route, 'fonts/manrope-regular.ttf')}" as="font" type="font/ttf" crossorigin>
  <link rel="preload" href="${asset(route, 'fonts/dm-serif-display.ttf')}" as="font" type="font/ttf" crossorigin>
  <link rel="stylesheet" href="${asset(route, 'styles.css')}">
  <script src="${asset(route, 'site.js')}" defer></script>
</head>
<body data-page="${route || 'home'}">
${header(route)}
<main id="main" tabindex="-1">${body}</main>
${footer(route)}
</body>
</html>`;
}

function home() {
  const route = '';
  return `<section class="hero wrap"><div class="hero-copy">${tag('Doradztwo dla branży motoryzacyjnej')}<h1>Dobre wyniki<br>zaczynają się<br><em>od środka.</em></h1><p class="hero-lead">Pomagam dealerom rozwijać serwis, sprzedaż części i ludzi, którzy za nimi stoją.</p><div class="hero-actions">${button(route, 'oferta', 'Poznaj możliwości')}<a class="text-link" href="${link(route, 'o-firmie')}">Poznajmy się ${diagonal}</a></div><div class="hero-byline"><span class="byline-monogram" aria-hidden="true">AS</span><p><strong>Andrzej Sadowski</strong><span>Doświadczenie w motoryzacji od 1991 roku</span></p></div></div><div class="hero-visual"><picture><source srcset="${asset(route, 'showroom-800.webp')} 800w, ${asset(route, 'showroom-1080.webp')} 1080w" sizes="(max-width: 760px) 92vw, 46vw" type="image/webp"><img class="hero-photo" src="${asset(route, 'showroom.jpg')}" alt="Ilustracyjna wizja nowoczesnego salonu samochodowego w naturalnym świetle" width="1080" height="1440" fetchpriority="high"></picture><div class="photo-topline"><span>Perspektywa rozwoju</span><span>01 / A.S.</span></div><div class="photo-caption"><span class="small-cross" aria-hidden="true">+</span>Jakość. Dostępność.<br>Efektywność.</div><div class="hero-stamp"><span>Praktyka doradcza</span><strong>od 2005</strong><span>Blisko Twojego biznesu</span></div></div></section>
  <section class="experience-strip"><div class="wrap"><p>Doświadczenie we współpracy<br>z sieciami dealerskimi</p><ul aria-label="Wybrane marki z historii współpracy"><li>BMW</li><li>RENAULT</li><li class="brand-ford">Ford</li><li>TOYOTA</li><li>HONDA</li></ul><a href="${link(route, 'klienci')}" class="small-link">Poznaj projekty ${diagonal}</a></div></section>
  <section class="wrap section-pad"><div class="section-heading">${sectionLabel('01', 'Obszary współpracy')}<div><h2>Twój potencjał.<br><em>Wspólny kierunek.</em></h2><p>Od pojedynczej decyzji po rozwój całej organizacji. Wybierz obszar, w którym Twoje dealerstwo potrzebuje wsparcia.</p></div></div>${serviceRows(route)}</section>
  <section class="program-section"><div class="wrap program-grid"><div class="program-copy">${tag('Autorski Program Rozwoju Dealera', true)}<h2>Zmiana ma sens,<br>gdy staje się<br><em>codziennością.</em></h2><p>Dobry audyt to początek. Dalej są decyzje, rozwój kompetencji i systematyczna praca z wynikami. Łączę te etapy w jeden program.</p>${button(route, 'oferta/program-rozwoju-dealera', 'Poznaj program')}</div><ol class="program-steps">${services[2].process.map(([title, text], i) => `<li><span class="step-index">0${i + 1}</span><div><h3>${title}${i === 3 ? '<span class="step-tag">3 miesiące</span>' : ''}</h3><p>${text}</p></div></li>`).join('')}</ol></div></section>
  <section class="wrap section-pad about-teaser"><div class="about-note"><span class="note-corner" aria-hidden="true">↗</span><p class="eyebrow">Perspektywa praktyka</p><p class="note-statement">Znam dealerstwo<br>od strony<br><em>codziennych decyzji.</em></p><div class="note-signature"><span>Andrzej Sadowski</span><span>A.S. Consulting</span></div></div><div class="about-teaser-copy">${sectionLabel('02', 'Doświadczenie ma znaczenie')}<h2>Od sprzedaży<br>do zarządzania.<br><em>Od praktyki do doradztwa.</em></h2><p>Pracowałem jako sprzedawca, kierownik, dyrektor działu części i dyrektor zarządzający. Dzięki temu patrzę na dealerstwo z perspektywy całej organizacji.</p><p>Dziś tę wiedzę wykorzystuję, wspierając właścicieli i kadrę zarządzającą w rozwoju ich biznesu.</p><a class="text-link" href="${link(route, 'o-firmie')}">Poznaj moje doświadczenie ${arrow}</a></div></section>
  <section class="wrap faq-section"><div>${sectionLabel('03', 'Zanim porozmawiamy')}<h2>Dobry początek<br>to <em>jasne odpowiedzi.</em></h2></div>${faq([
    ['Od czego najlepiej zacząć?', 'Od rozmowy o obecnej sytuacji i obszarze, który chcesz poprawić. Na tej podstawie możemy dobrać zakres współpracy: doradztwo, szkolenia lub Program Rozwoju Dealera.'],
    ['Czy współpraca dotyczy tylko autoryzowanych dealerów?', 'Doświadczenie obejmuje także niezależne firmy zajmujące się sprzedażą i obsługą samochodów oraz dystrybutorów części. Opisz swój biznes, aby omówić możliwy zakres wsparcia.'],
    ['Czy mogę skupić się na serwisie lub dziale części?', 'Tak. Doradztwo i szkolenia obejmują konkretne obszary obsługi posprzedażnej. Szerszą analizę ich współpracy umożliwia Program Rozwoju Dealera.'],
  ])}</section>${cta(route)}`;
}

function about() {
  const route = 'o-firmie';
  return `${pageIntro(route, { title: 'O mnie', eyebrow: 'Andrzej Sadowski · A.S. Consulting', heading: 'Doradztwo z perspektywy', emphasis: 'człowieka z branży.', intro: 'Zanim zacząłem doradzać dealerom, sam pracowałem w ich zespołach i nimi zarządzałem. To doświadczenie jest podstawą mojego sposobu pracy.' })}
  <section class="wrap bio-grid"><div class="identity-panel"><span class="identity-mark" aria-hidden="true">A.S.</span><div><p class="eyebrow">Praktyka. Perspektywa. Rozwój.</p><h2>Andrzej<br>Sadowski</h2><p>Niezależny konsultant<br>ds. rozwoju dealerstwa</p></div><span class="identity-foot">W branży motoryzacyjnej od 1991 roku</span></div><div class="bio-copy"><h2>Rozumiem, jak poszczególne działy wpływają na <em>cały biznes.</em></h2><p>Moja droga zawodowa prowadziła od sprzedaży samochodów, przez kierowanie zakładem dealerskim i działem części, po stanowisko dyrektora zarządzającego.</p><p>Praca w organizacjach związanych z grupami Sumitomo oraz Bawaria–PGA pozwoliła mi przyglądać się różnym modelom działania dealerów. W centrum zawsze pozostawały trzy rzeczy: jakość, dostępność i efektywność pracy.</p><p>W 2005 roku rozpocząłem działalność A.S. Consulting. Opracowałem autorski Program Rozwoju Dealera, skupiony na organizacji i rozwoju działów obsługi posprzedażnej.</p><a class="text-link" href="${link(route, 'oferta/program-rozwoju-dealera')}">Poznaj mój program ${arrow}</a></div></section>
  <section class="wrap section-pad"><div class="section-heading">${sectionLabel('01', 'Droga zawodowa')}<div><h2>Doświadczenie budowane<br><em>krok po kroku.</em></h2><p>Różne stanowiska. Różne marki. Jedna branża, którą znam od środka.</p></div></div><ol class="career-list">${career.map(([year, name, role, description]) => `<li><span class="career-year">${year}</span><div><h3>${name}</h3><p class="career-role">${role}</p></div><p>${description}</p></li>`).join('')}</ol></section>
  <section class="values-section"><div class="wrap"><div class="section-heading">${sectionLabel('02', 'Sposób myślenia')}<div><h2>Trzy punkty odniesienia.<br><em>W każdej decyzji.</em></h2></div></div><div class="values-grid">${[['01', 'Jakość', 'Spójna obsługa, dobra komunikacja i organizacja pracy, na której klient może polegać.'], ['02', 'Dostępność', 'Usługi i części dostępne wtedy, kiedy są potrzebne. Potencjał, który faktycznie służy klientom.'], ['03', 'Efektywność', 'Świadome wykorzystanie czasu, kompetencji i zasobów. Decyzje oparte na kluczowych parametrach pracy.']].map(([n, t, d]) => `<article><span class="value-number">${n}</span><h3>${t}</h3><p>${d}</p></article>`).join('')}</div></div></section>${cta(route)}`;
}

function offer() {
  const route = 'oferta';
  return `${pageIntro(route, { title: 'Oferta', eyebrow: 'Oferta A.S. Consulting', heading: 'Dla każdego wyzwania', emphasis: 'właściwa perspektywa.', intro: 'Audyty, doradztwo, szkolenia i kompleksowy program rozwoju. Cztery sposoby, aby przyjrzeć się Twojemu biznesowi i wesprzeć kolejne decyzje.' })}
  <section class="wrap offer-cards" aria-label="Usługi">${services.map((s) => `<article class="offer-card"><div class="offer-card-top"><span class="service-number">${s.number} /</span>${icon(s.icon)}</div><h2><a href="${link(route, s.path)}">${s.title}</a></h2><p class="offer-card-short">${s.short}</p><p>${s.description}</p><a class="text-link" href="${link(route, s.path)}">Poznaj zakres<span class="sr-only">: ${s.title}</span> ${arrow}</a></article>`).join('')}</section>
  <section class="wrap section-pad"><div class="section-heading">${sectionLabel('01', 'Znajdź punkt wyjścia')}<div><h2>Co chcesz<br><em>zmienić lub sprawdzić?</em></h2></div></div><div class="decision-list">${[
    ['Chcę sprawdzić standardy w sieci dealerskiej.', 'audyty', 'Audyt standardów producenta'],
    ['Potrzebuję wsparcia w konkretnej decyzji biznesowej.', 'doradztwo', 'Doradztwo dopasowane do zagadnienia'],
    ['Chcę przyjrzeć się całej obsłudze posprzedażnej.', 'program-rozwoju-dealera', 'Program od audytu po monitoring'],
    ['Chcę rozwinąć kompetencje moich kierowników.', 'szkolenia', 'Szkolenia z zarządzania serwisem i częściami'],
  ].map(([q, id, desc]) => `<a href="${link(route, `oferta/${id}`)}"><h3>${q}</h3><span>${desc}</span>${arrow}</a>`).join('')}</div></section>${cta(route, { title: 'Nie wiesz jeszcze,', emphasis: 'od czego zacząć?', text: 'Nie musisz wybierać usługi przed pierwszą rozmową. Zacznijmy od Twojej sytuacji i celu.' })}`;
}

function servicePage(s) {
  const route = s.path;
  const related = services.find((item) => item.id === s.next);
  return `${breadcrumbs(route, s.title, true)}<section class="wrap service-hero"><div>${tag(s.eyebrow)}<h1>${s.heading}<br><em>${s.emphasis}</em></h1><p class="lead">${s.intro}</p>${topicButton(route, s.title, 'Porozmawiajmy o tym')}</div><aside class="service-brief"><div class="service-brief-top"><span>${s.number} / 04</span>${icon(s.icon)}</div><div><h2>Dla kogo</h2><p>${s.audience}</p></div><div><h2>Co wnosi współpraca</h2><p>${s.result}</p></div><a href="#zakres">Zobacz zakres ${arrow}</a></aside></section>
  <section class="wrap section-pad service-scope" id="zakres"><div class="section-heading">${sectionLabel('01', 'Zakres współpracy')}<div><h2>${s.openingTitle}</h2><p>${s.opening}</p></div></div><div class="scope-grid">${s.areas.map(([title, text], i) => `<article><span class="scope-index">0${i + 1}</span><h3>${title}</h3><p>${text}</p></article>`).join('')}</div></section>
  ${s.id === 'szkolenia' ? trainingPrograms() : ''}
  <section class="process-section"><div class="wrap"><div class="section-heading">${sectionLabel('02', 'Przebieg współpracy')}<div><h2>${s.id === 'program-rozwoju-dealera' ? 'Od diagnozy do' : 'Jasny cel.'}<br><em>${s.id === 'program-rozwoju-dealera' ? 'codziennej praktyki.' : 'Przemyślany proces.'}</em></h2></div></div><ol class="process-grid ${s.process.length === 4 ? 'process-four' : ''}">${s.process.map(([title, text], i) => `<li><span class="process-number">0${i + 1}</span><h3>${title}</h3><p>${text}</p></li>`).join('')}</ol>${s.id === 'program-rozwoju-dealera' ? '<div class="monitor-note"><strong>3 miesiące monitoringu</strong><p>Cotygodniowe dane. Comiesięczne spotkania. Stały punkt odniesienia dla kierowników.</p></div>' : ''}</div></section>
  <section class="wrap faq-section"><div>${sectionLabel('03', 'Pytania i odpowiedzi')}<h2>Warto wiedzieć<br><em>przed rozpoczęciem.</em></h2></div>${faq(s.faq)}</section>
  <section class="wrap related-section"><span class="eyebrow">Spójrz również na</span><a href="${link(route, related.path)}"><div><h2>${related.title}</h2><p>${related.description}</p></div><span class="round-arrow">${diagonal}</span></a></section>${cta(route, { topic: s.title })}`;
}

function trainingPrograms() {
  return `<section class="wrap training-section"><h2>Dwa działy.<br><em>Dwa praktyczne zakresy.</em></h2><div class="training-grid"><article><p class="eyebrow">Program szkolenia / 01</p><h3>Zarządzanie serwisem mechanicznym</h3><ul class="check-list"><li>Pojęcia i definicje</li><li>Zarządzanie biurem obsługi klienta</li><li>Zarządzanie warsztatem</li><li>Współpraca serwisu i działu części</li><li>Monitoring — kluczowe parametry pracy (KPI)</li></ul></article><article><p class="eyebrow">Program szkolenia / 02</p><h3>Zarządzanie działem części zamiennych</h3><ul class="check-list"><li>Pojęcia i definicje</li><li>Zarządzanie magazynem</li><li>Zarządzanie sprzedażą wewnętrzną</li><li>Sprzedaż zewnętrzna i hurtowa</li><li>Monitoring — kluczowe parametry pracy (KPI)</li></ul></article></div></section>`;
}

function clientsPage() {
  const route = 'klienci';
  return `${pageIntro(route, { title: 'Klienci', eyebrow: 'Doświadczenie we współpracy', heading: 'Różne marki.', emphasis: 'Znajome wyzwania.', intro: 'Projekty dla sieci dealerskich samochodów osobowych i użytkowych. Szkolenia, audyty i praca nad rozwojem organizacji.' })}
  <section class="wrap client-intro"><p>Wybrane marki i organizacje z historii współpracy A.S. Consulting.</p><span>Szkolenia / Audyty / Rozwój</span></section>
  <section class="wrap clients-grid" aria-label="Wybrane projekty">${clients.map((c, i) => `<article class="client-card"><div class="client-card-top"><span class="client-number">0${i + 1}</span><span>${c.field}</span></div><h2>${c.name}</h2><p>${c.text}</p><span class="client-period">${c.period}</span></article>`).join('')}</section>
  <section class="wrap independent-section"><span class="service-icon">${icon('people')}</span><div><h2>Również poza sieciami autoryzowanymi.</h2><p>Doświadczenie obejmuje także niezależne firmy sprzedaży i obsługi samochodów oraz dystrybutorów części zamiennych.</p></div></section>
  <section class="client-perspective"><div class="wrap split-section"><div>${sectionLabel('01', 'Wspólny mianownik')}<h2>Każda organizacja<br>ma własny<br><em>potencjał rozwoju.</em></h2></div><div><p>Marki, struktury i rynki są różne. W codziennej pracy powracają jednak podobne pytania: jak wykorzystać zasoby, jak usprawnić współpracę działów i jak zapewnić klientom dobrą obsługę.</p><p>Dlatego punktem wyjścia jest zawsze konkretna sytuacja firmy, a nie gotowa odpowiedź.</p><a class="text-link" href="${link(route, 'oferta')}">Zobacz obszary wsparcia ${arrow}</a></div></div></section>${cta(route)}`;
}

function contact() {
  const route = 'kontakt';
  return `${pageIntro(route, { title: 'Kontakt', eyebrow: 'Porozmawiajmy o Twoim dealerstwie', heading: 'Dobra zmiana zaczyna się', emphasis: 'od rozmowy.', intro: 'Masz konkretny temat lub dopiero szukasz właściwego kierunku? Napisz albo zadzwoń. Zacznijmy od tego, co jest teraz ważne dla Twojej firmy.' })}
  <section class="wrap contact-grid"><div class="contact-direct"><p class="section-label"><span>01</span>Bezpośrednio do mnie</p><h2>Andrzej Sadowski</h2><p class="contact-role">A.S. Consulting</p><a class="contact-channel" href="tel:${company.phoneHref}"><span>${icon('phone')}</span><span><small>Zadzwoń</small><strong>${company.phone}</strong></span>${diagonal}</a><a class="contact-channel" href="mailto:${company.email}"><span>${icon('mail')}</span><span><small>Napisz</small><strong>${company.email}</strong></span>${diagonal}</a><div class="contact-tip"><span class="small-cross" aria-hidden="true">+</span><h3>Nie potrzebujesz gotowego briefu.</h3><p>Wystarczy kilka zdań o Twojej firmie, obecnej sytuacji i tym, co chcesz poprawić.</p></div></div>
  <div class="contact-compose"><p class="section-label"><span>02</span>Uporządkuj swój temat</p><h2>O czym porozmawiamy?</h2><p>Przygotuj treść, a następnie otwórz ją w swojej poczcie lub skopiuj. Wiadomość wyślesz samodzielnie.</p><noscript><p class="notice">Aby skorzystać z kreatora wiadomości, włącz JavaScript. Możesz też napisać bezpośrednio na <a href="mailto:${company.email}">${company.email}</a>.</p></noscript>
  <form id="contact-form" class="contact-form" hidden><div id="form-errors" class="form-errors" tabindex="-1" hidden><p>Sprawdź zaznaczone pola:</p><ul></ul></div><div class="form-row"><div class="form-field"><label for="name">Imię i nazwisko <span>(wymagane)</span></label><input id="name" name="name" autocomplete="name" required maxlength="100" aria-describedby="name-error"><span class="field-error" id="name-error"></span></div><div class="form-field"><label for="email">Adres e-mail <span>(wymagany)</span></label><input id="email" name="email" type="email" autocomplete="email" required maxlength="160" aria-describedby="email-error"><span class="field-error" id="email-error"></span></div></div><div class="form-field"><label for="company">Firma <span>(opcjonalnie)</span></label><input id="company" name="company" autocomplete="organization" maxlength="160"></div><div class="form-field"><label for="topic">Temat rozmowy</label><select id="topic" name="topic"><option value="Rozmowa o współpracy">Chcę porozmawiać o możliwościach</option>${services.map((s) => `<option value="${s.title}">${s.title}</option>`).join('')}</select></div><div class="form-field"><label for="message">Twoja sytuacja <span>(wymagane)</span></label><textarea id="message" name="message" rows="5" required minlength="10" maxlength="2000" aria-describedby="message-hint message-error" placeholder="Co chcesz poprawić? Z jakim wyzwaniem mierzy się Twoja firma?"></textarea><div class="field-meta"><span id="message-hint">Wystarczy kilka zdań (minimum 10 znaków).</span><span id="message-count">0 / 2000</span></div><span class="field-error" id="message-error"></span></div><button class="button" type="submit">Przygotuj wiadomość ${arrow}</button><p class="form-note">Przygotowanie treści nie wysyła wiadomości.</p></form>
  <section id="message-preview" class="message-preview" hidden aria-labelledby="preview-heading"><p class="eyebrow">Treść jest gotowa</p><h3 id="preview-heading" tabindex="-1">Twój kolejny krok.</h3><p>Otwórz wiadomość w aplikacji pocztowej i wyślij ją albo skopiuj treść do swojej poczty.</p><label for="draft">Podgląd wiadomości</label><textarea id="draft" rows="9" readonly></textarea><div class="preview-actions"><a id="open-email" class="button" href="mailto:${company.email}">Otwórz pocztę ${diagonal}</a><button id="copy-message" class="button button-secondary" type="button">Kopiuj treść</button></div><p id="copy-status" class="copy-status" role="status" aria-live="polite"></p><button id="edit-message" class="text-link" type="button">Wróć do edycji ${arrow}</button></section></div></section>
  <section class="wrap contact-next"><h2>Co warto zawrzeć w wiadomości?</h2><ol><li><span>01</span><h3>Kilka słów o firmie</h3><p>Typ działalności i dział, którego dotyczy temat.</p></li><li><span>02</span><h3>Obecna sytuacja</h3><p>Najważniejsze wyzwanie lub decyzja do podjęcia.</p></li><li><span>03</span><h3>Twój cel</h3><p>Co chcesz usprawnić, sprawdzić lub rozwinąć.</p></li></ol></section>`;
}

export function pages() {
  return [
    { route: '', title: 'Rozwój dealerstwa zaczyna się od środka', description: 'Andrzej Sadowski — doradztwo dla dealerów, audyty, szkolenia i Program Rozwoju Dealera. Rozwój serwisu i działu części. A.S. Consulting od 2005 roku.', body: home() },
    { route: 'o-firmie', title: 'Andrzej Sadowski — doświadczenie i podejście', description: 'Poznaj Andrzeja Sadowskiego. Doświadczenie w motoryzacji od 1991 roku: od sprzedaży do zarządzania dealerstwem i własnej praktyki A.S. Consulting.', body: about() },
    { route: 'oferta', title: 'Audyty, doradztwo i szkolenia dla dealerów', description: 'Poznaj cztery obszary współpracy: audyty standardów, doradztwo, Program Rozwoju Dealera i szkolenia z zarządzania serwisem oraz częściami.', body: offer() },
    ...services.map((s) => ({ route: s.path, title: s.title, description: s.intro, body: servicePage(s) })),
    { route: 'klienci', title: 'Klienci i historia współpracy', description: 'Wybrane projekty A.S. Consulting dla sieci BMW, Renault, Ford, Toyota, Nissan, Honda i innych. Szkolenia, audyty i rozwój dealerów.', body: clientsPage() },
    { route: 'kontakt', title: 'Kontakt z Andrzejem Sadowskim', description: 'Porozmawiajmy o rozwoju Twojego dealerstwa. Andrzej Sadowski: +48 601 240 928, andrzej@sadowski-consulting.pl.', body: contact() },
  ];
}

export function notFound() {
  return layout({ route: '', title: 'Nie znaleziono strony', description: 'Wróć do strony głównej A.S. Consulting lub poznaj ofertę doradztwa dla dealerów.', body: `<section class="wrap not-found">${tag('404 · Nie znaleziono strony')}<h1>Wróćmy na<br><em>właściwą drogę.</em></h1><p>Ta strona nie istnieje lub zmieniła adres. Przejdź do strony głównej albo sprawdź ofertę.</p><div class="hero-actions">${button('', '', 'Strona główna')}${button('', 'oferta', 'Poznaj ofertę', true)}</div></section>` });
}
