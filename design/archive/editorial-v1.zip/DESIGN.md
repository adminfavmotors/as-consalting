# A.S. Consulting — design direction

Premium editorial, grounded in automotive operations. The visual idea is “inside the dealership”: a quiet architectural photograph, typography with character, and clearly numbered areas of work.

## Decisions

- Warm paper `#f6f5ef`, forest green `#193c36`, pale lime `#dae9ab`, sage `#e8ecdf`.
- Body text `#223a34`; secondary text `#626b61`. Dark backgrounds use `#edf0e6` / `#c2cec3`.
- DM Serif Display for headlines, with selective italic emphasis. Manrope for supporting copy and controls.
- Local font files, including Polish characters. Font licensing files ship alongside assets.
- Asymmetric two-column home hero; smaller inner-page introductions; numbered service rows; quiet rules instead of decorative cards everywhere.
- Static brand names describe historical work; they are not fabricated endorsements or unofficial logos.
- No invented portrait, client testimonials, performance percentages, certifications, prices or current partnership claims.
- Finite CSS entrance animations only. Reduced-motion users see the final state with no animation.
- Keyboard focus indicators, skip link, semantic page landmarks, visible field labels and native FAQ disclosures.
- Responsive layouts at 1150, 900, 760 and 370px. Mobile navigation is progressively enhanced; without JavaScript the links remain visible.

## Skill application

Read `frontend-design` and `ui-ux-pro-max`. The first design-system search returned an Apple Liquid Glass pattern inappropriate for this B2B website, so it was discarded. The narrower consulting/editorial search supported a trust-led structure, restrained typography, high contrast and clear contact paths. Font and colour recommendations were consciously adapted to this specific brand direction; no unverified search output was persisted as a design mandate.

## Photograph

`showroom-original.png`: generated with the built-in imagegen tool for this project. Architectural, unbranded automotive showroom scene. It is illustrative and does not represent the client's own premises. Inspected before use; optimized variants retain the composition. The image alt text identifies it as an illustrative scene.

Only optimized images from `public/assets/` are included in the final static site. The original remains in this design directory for future work.
